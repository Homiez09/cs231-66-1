// 6510405750 ภูมิระพี เสริญวณิชกุล
package com.example.designpattern.Email;

public interface EmailEncryptionStrategy {
    String encrypt(String text);
}

